import { NextResponse } from "next/server";
import { db } from "@/db";
import { customers, orders } from "@/db/schema";
import { asc, eq, desc } from "drizzle-orm";
import { authorize } from "@/lib/auth";

export async function GET() {
  const { error: authError } = await authorize("customers:read");
  if (authError) return authError;

  try {
    const allCustomers = await db.select().from(customers).orderBy(asc(customers.company));
    const allOrders = await db.select().from(orders);

    const enriched = allCustomers.map(c => {
      const custOrders = allOrders.filter(o => o.customerId === c.id);
      const activeOrdersCount = custOrders.filter(o => o.status !== "Completed" && o.status !== "On Hold").length;
      const totalSpend = custOrders.reduce((sum, o) => sum + parseFloat(o.totalValue || "0"), 0);

      return {
        ...c,
        orderCount: custOrders.length,
        activeOrdersCount,
        totalSpend: totalSpend.toFixed(2),
      };
    });

    return NextResponse.json(enriched);
  } catch (error: any) {
    console.error("GET customers error:", error);
    return NextResponse.json({ error: error?.message || "Failed to fetch customers" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const { error: authError } = await authorize("customers:write");
  if (authError) return authError;

  try {
    const body = await request.json();
    const { name, company, email, phone, address = "", creditLimit = "15000.00", notes = "" } = body;

    if (!name || !company || !email || !phone) {
      return NextResponse.json({ error: "Name, Company, Email and Phone are required." }, { status: 400 });
    }

    const [newCustomer] = await db.insert(customers).values({
      name,
      company,
      email,
      phone,
      address,
      creditLimit: String(creditLimit),
      currentBalance: "0.00",
      notes
    }).returning();

    return NextResponse.json(newCustomer, { status: 201 });
  } catch (error: any) {
    console.error("POST customer error:", error);
    return NextResponse.json({ error: error?.message || "Failed to create customer" }, { status: 500 });
  }
}
