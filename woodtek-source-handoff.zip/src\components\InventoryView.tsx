"use client";

import React, { useState } from "react";
import { Package, Plus, AlertTriangle, CheckCircle2, DollarSign, Tag, Layers, Trash2, X, RefreshCw } from "lucide-react";

interface InventoryViewProps {
  items: any[];
  loading: boolean;
  onRefresh: () => void;
}

export default function InventoryView({ items = [], loading, onRefresh }: InventoryViewProps) {
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);
  const [sku, setSku] = useState("");
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Wood & MDF Panels");
  const [stockQuantity, setStockQuantity] = useState("100");
  const [unit, setUnit] = useState("sheets");
  const [unitCost, setUnitCost] = useState("65.00");
  const [reorderLevel, setReorderLevel] = useState("20");
  const [location, setLocation] = useState("Rack 1-A");

  const categories = ["All", "Wood & MDF Panels", "Edge Banding", "Hardware & Fittings", "Coatings & Adhesives"];

  const filtered = categoryFilter === "All" ? items : items.filter(i => i.category === categoryFilter);

  const handleAdjustStock = async (id: number, currentQty: number, delta: number) => {
    const newQty = Math.max(0, currentQty + delta);
    try {
      await fetch(`/api/inventory/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ stockQuantity: newQty }),
      });
      onRefresh();
    } catch (err) {
      console.error("Adjust error", err);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch("/api/inventory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sku, name, category, stockQuantity: Number(stockQuantity), unit, unitCost, reorderLevel: Number(reorderLevel), location }),
      });
      if (!res.ok) throw new Error("Failed to create item");
      setShowModal(false);
      setSku("");
      setName("");
      onRefresh();
    } catch (err) {
      console.error("Create inventory error", err);
      alert("Error adding item. SKU must be unique.");
    }
  };

  const handleDelete = async (id: number, itemName: string) => {
    if (!confirm(`Remove ${itemName} from shop stock?`)) return;
    try {
      await fetch(`/api/inventory/${id}`, { method: "DELETE" });
      onRefresh();
    } catch (err) {
      console.error("Delete inventory error", err);
    }
  };

  if (loading) return <div className="p-6 text-slate-400 animate-pulse">Loading material inventory...</div>;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800/80 p-4 rounded-2xl shadow-sm">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-400 mr-1">Category:</span>
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setCategoryFilter(c)}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition ${
                categoryFilter === c
                  ? "bg-amber-500 text-slate-950 font-black shadow"
                  : "bg-slate-950/60 text-slate-300 hover:bg-slate-800 border border-slate-800"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-extrabold text-xs px-4 py-2 rounded-xl shadow-md transition flex items-center gap-1.5 whitespace-nowrap"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" /> Receive / Add Stock Item
        </button>
      </div>

      {/* Items Table */}
      <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/50 text-slate-400 font-bold text-xs uppercase tracking-wider">
                <th className="py-3.5 px-5">SKU & Item Name</th>
                <th className="py-3.5 px-4">Category</th>
                <th className="py-3.5 px-4">Shop Location</th>
                <th className="py-3.5 px-4 text-right">Unit Cost</th>
                <th className="py-3.5 px-4 text-center">Stock Quantity</th>
                <th className="py-3.5 px-4 text-center">Status</th>
                <th className="py-3.5 px-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-xs text-slate-200">
              {filtered.map((item) => {
                const isLow = item.stockQuantity <= item.reorderLevel;
                return (
                  <tr key={item.id} className="hover:bg-slate-850/60 transition">
                    <td className="py-4 px-5 font-medium">
                      <div className="font-mono text-[11px] font-black text-amber-400">{item.sku}</div>
                      <div className="text-sm font-extrabold text-white mt-0.5">{item.name}</div>
                    </td>
                    <td className="py-4 px-4 text-slate-300 font-semibold">{item.category}</td>
                    <td className="py-4 px-4 text-slate-400 font-mono">{item.location}</td>
                    <td className="py-4 px-4 text-right font-mono font-black text-white">${Number(item.unitCost).toFixed(2)}</td>
                    <td className="py-4 px-4 text-center">
                      <div className="inline-flex items-center gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
                        <button
                          onClick={() => handleAdjustStock(item.id, item.stockQuantity, -5)}
                          className="w-6 h-6 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold"
                          title="Reduce stock (-5)"
                        >
                          -
                        </button>
                        <span className="w-16 text-center font-mono font-black text-sm text-white">
                          {item.stockQuantity} {item.unit}
                        </span>
                        <button
                          onClick={() => handleAdjustStock(item.id, item.stockQuantity, 10)}
                          className="w-6 h-6 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold"
                          title="Add received stock (+10)"
                        >
                          +
                        </button>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-center">
                      {isLow ? (
                        <span className="inline-flex items-center gap-1 bg-rose-500/20 text-rose-300 border border-rose-500/30 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase">
                          <AlertTriangle className="w-3 h-3 text-rose-400" /> Reorder Needed
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Optimal Stock
                        </span>
                      )}
                    </td>
                    <td className="py-4 px-5 text-right">
                      <button
                        onClick={() => handleDelete(item.id, item.name)}
                        className="p-2 hover:bg-rose-500/20 text-slate-600 hover:text-rose-400 rounded-xl transition"
                        title="Delete item"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Register Raw Material Item</h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleCreate} className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">SKU *</label>
                  <input type="text" required placeholder="BRD-WHT-18" value={sku} onChange={e => setSku(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono uppercase" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Category</label>
                  <select value={category} onChange={e => setCategory(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white">
                    {categories.filter(c => c !== "All").map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Item Specification Name *</label>
                <input type="text" required placeholder="e.g. Matte White Supermatt Melamine 18mm" value={name} onChange={e => setName(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Initial Qty</label>
                  <input type="number" value={stockQuantity} onChange={e => setStockQuantity(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Unit</label>
                  <input type="text" value={unit} onChange={e => setUnit(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Unit Cost ($)</label>
                  <input type="number" step="0.01" value={unitCost} onChange={e => setUnitCost(e.target.value)} className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono" />
                </div>
              </div>
              <div className="flex justify-end gap-3 pt-3 border-t border-slate-800">
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow">Register Item</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
