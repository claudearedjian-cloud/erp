import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, customers, orderOperations, orderMaterials, machines, operationTemplates } from "@/db/schema";
import { eq, desc, asc, sql } from "drizzle-orm";
import { authorize } from "@/lib/auth";

export async function GET(request: Request) {
  const { error: authError } = await authorize("orders:read");
  if (authError) return authError;

  try {
    const url = new URL(request.url);
    const status = url.searchParams.get("status");

    // Fetch all orders with their customer and operation details
    const allOrders = await db
      .select({
        id: orders.id,
        orderNumber: orders.orderNumber,
        title: orders.title,
        projectType: orders.projectType,
        priority: orders.priority,
        status: orders.status,
        totalValue: orders.totalValue,
        dueDate: orders.dueDate,
        progressPercent: orders.progressPercent,
        notes: orders.notes,
        createdAt: orders.createdAt,
        customerId: orders.customerId,
        customerName: customers.name,
        customerCompany: customers.company,
      })
      .from(orders)
      .leftJoin(customers, eq(orders.customerId, customers.id))
      .orderBy(desc(orders.createdAt));

    // For each order, fetch summary of operations and active station
    const allOperations = await db
      .select({
        id: orderOperations.id,
        orderId: orderOperations.orderId,
        stepOrder: orderOperations.stepOrder,
        operationName: orderOperations.operationName,
        status: orderOperations.status,
        machineName: machines.name,
        machineCode: machines.code,
      })
      .from(orderOperations)
      .leftJoin(machines, eq(orderOperations.machineId, machines.id))
      .orderBy(asc(orderOperations.stepOrder));

    const enrichedOrders = allOrders.map(order => {
      const ops = allOperations.filter(o => o.orderId === order.id);
      const totalSteps = ops.length;
      const completedSteps = ops.filter(o => o.status === "Completed").length;
      const currentOp = ops.find(o => o.status === "In Progress") || ops.find(o => o.status === "Ready") || ops.find(o => o.status === "Pending") || ops[ops.length - 1];

      return {
        ...order,
        totalSteps,
        completedSteps,
        currentStation: currentOp ? {
          operationName: currentOp.operationName,
          machineCode: currentOp.machineCode || "Unassigned",
          machineName: currentOp.machineName || "Pending station allocation",
          status: currentOp.status
        } : null,
        operations: ops
      };
    });

    if (status && status !== "All") {
      return NextResponse.json(enrichedOrders.filter(o => o.status.toLowerCase() === status.toLowerCase()));
    }

    return NextResponse.json(enrichedOrders);
  } catch (error: any) {
    console.error("GET orders error:", error);
    return NextResponse.json({ error: error?.message || "Failed to fetch orders" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const { error: authError } = await authorize("orders:write");
  if (authError) return authError;

  try {
    const body = await request.json();
    const { 
      orderNumber, 
      customerId, 
      title, 
      projectType, 
      priority = "Normal", 
      totalValue = "0.00", 
      dueDate, 
      notes, 
      templateId, 
      customSteps = [] 
    } = body;

    if (!customerId || !title || !dueDate) {
      return NextResponse.json({ error: "Customer, Title, and Due Date are required." }, { status: 400 });
    }

    // Generate random order number if not supplied
    const finalOrderNum = orderNumber || `ORD-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const [newOrder] = await db.insert(orders).values({
      orderNumber: finalOrderNum,
      customerId: Number(customerId),
      title,
      projectType: projectType || "Custom Furniture",
      priority,
      status: "Pending",
      totalValue: String(totalValue),
      dueDate: new Date(dueDate),
      progressPercent: 0,
      notes: notes || null,
    }).returning();

    // Fetch all available machines so we can auto-assign matching categories
    const allMachines = await db.select().from(machines);

    // If template selected, generate workflow from template
    if (templateId) {
      const [tpl] = await db.select().from(operationTemplates).where(eq(operationTemplates.id, Number(templateId)));
      if (tpl && Array.isArray(tpl.defaultStepsJson)) {
        for (let i = 0; i < tpl.defaultStepsJson.length; i++) {
          const step = tpl.defaultStepsJson[i] as any;
          // Find best matching machine in category
          const matchingMachine = allMachines.find(m => m.category.toLowerCase().includes(step.machineCategory?.toLowerCase() || "")) || allMachines[0];
          
          await db.insert(orderOperations).values({
            orderId: newOrder.id,
            machineId: matchingMachine ? matchingMachine.id : null,
            stepOrder: step.stepOrder || i + 1,
            operationName: step.operationName || `Step ${i + 1}`,
            estimatedMinutes: step.estimatedMinutes || 60,
            status: i === 0 ? "Ready" : "Pending", // First step is automatically Ready!
          });
        }
      }
    } else if (customSteps.length > 0) {
      for (let i = 0; i < customSteps.length; i++) {
        const step = customSteps[i];
        await db.insert(orderOperations).values({
          orderId: newOrder.id,
          machineId: step.machineId ? Number(step.machineId) : null,
          stepOrder: i + 1,
          operationName: step.operationName || `Operation ${i + 1}`,
          estimatedMinutes: step.estimatedMinutes ? Number(step.estimatedMinutes) : 60,
          status: i === 0 ? "Ready" : "Pending",
        });
      }
    } else {
      // Default basic workflow if none selected
      const saw = allMachines.find(m => m.category === "Panel Saw") || allMachines[0];
      const asm = allMachines.find(m => m.category === "Assembly Table") || allMachines[1] || allMachines[0];

      await db.insert(orderOperations).values([
        { orderId: newOrder.id, machineId: saw?.id || null, stepOrder: 1, operationName: "Standard Panel Sizing & Cutting", estimatedMinutes: 90, status: "Ready" },
        { orderId: newOrder.id, machineId: asm?.id || null, stepOrder: 2, operationName: "Assembly & Quality Assurance", estimatedMinutes: 120, status: "Pending" }
      ]);
    }

    return NextResponse.json(newOrder, { status: 201 });
  } catch (error: any) {
    console.error("POST order error:", error);
    return NextResponse.json({ error: error?.message || "Failed to create order" }, { status: 500 });
  }
}
