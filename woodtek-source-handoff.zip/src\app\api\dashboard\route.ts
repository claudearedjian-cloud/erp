import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, machines, orderOperations, inventoryItems, customers, users } from "@/db/schema";
import { eq, desc, asc, sql } from "drizzle-orm";
import { authorize } from "@/lib/auth";

export async function GET() {
  const { error: authError } = await authorize();
  if (authError) return authError;

  try {
    const [allOrders, allMachines, allOps, allInventory, allCustomers, allUsers] = await Promise.all([
      db.select().from(orders),
      db.select().from(machines),
      db.select({
        id: orderOperations.id,
        orderId: orderOperations.orderId,
        machineId: orderOperations.machineId,
        stepOrder: orderOperations.stepOrder,
        operationName: orderOperations.operationName,
        status: orderOperations.status,
        estimatedMinutes: orderOperations.estimatedMinutes,
        actualMinutes: orderOperations.actualMinutes,
        startTime: orderOperations.startTime,
        endTime: orderOperations.endTime,
        updatedAt: orderOperations.updatedAt,
        machineName: machines.name,
        machineCode: machines.code,
        orderTitle: orders.title,
        orderNumber: orders.orderNumber,
        operatorName: users.name,
      })
      .from(orderOperations)
      .leftJoin(machines, eq(orderOperations.machineId, machines.id))
      .leftJoin(orders, eq(orderOperations.orderId, orders.id))
      .leftJoin(users, eq(orderOperations.operatorId, users.id)),
      db.select().from(inventoryItems),
      db.select().from(customers),
      db.select().from(users),
    ]);

    // Order KPIs
    const activeOrders = allOrders.filter(o => o.status === "In Production" || o.status === "Pending" || o.status === "Quality Review");
    const totalPipelineValue = activeOrders.reduce((sum, o) => sum + parseFloat(o.totalValue || "0"), 0);
    const urgentOrdersCount = activeOrders.filter(o => o.priority === "Urgent" || o.priority === "High").length;
    const completedThisMonth = allOrders.filter(o => o.status === "Completed").length;

    // Machine Utilization & Bottleneck Analysis
    const totalMachines = allMachines.length;
    const inUseMachines = allMachines.filter(m => {
      const activeJob = allOps.find(o => o.machineId === m.id && o.status === "In Progress");
      return activeJob || m.status === "In-Use";
    }).length;
    
    const maintenanceMachines = allMachines.filter(m => m.status === "Maintenance" || m.status === "Offline").length;
    const utilizationRate = totalMachines > 0 ? Math.round((inUseMachines / totalMachines) * 100) : 0;

    // Bottlenecks: Find machines with highest number of "Ready" or "In Progress" steps
    const machineWorkloads = allMachines.map(m => {
      const queue = allOps.filter(o => o.machineId === m.id && (o.status === "Ready" || o.status === "In Progress"));
      const totalMinutes = queue.reduce((s, o) => s + (o.estimatedMinutes || 0), 0);
      return {
        machineId: m.id,
        name: m.name,
        code: m.code,
        category: m.category,
        status: m.status,
        queueLength: queue.length,
        estimatedHours: Math.round((totalMinutes / 60) * 10) / 10,
        hourlyCost: m.hourlyCost,
      };
    }).sort((a, b) => b.queueLength - a.queueLength);

    const primaryBottleneck = machineWorkloads.find(m => m.queueLength > 0) || null;

    // Inventory Alerts
    const lowStockItems = allInventory.filter(i => i.stockQuantity <= i.reorderLevel);

    // Recent Operational Activity
    const activeShopJobs = allOps.filter(o => o.status === "In Progress" || o.status === "Ready").slice(0, 6);

    return NextResponse.json({
      kpis: {
        activeOrdersCount: activeOrders.length,
        totalPipelineValue: totalPipelineValue.toFixed(2),
        urgentOrdersCount,
        completedOrdersCount: completedThisMonth,
        utilizationRate,
        inUseMachines,
        totalMachines,
        maintenanceMachines,
        customerCount: allCustomers.length,
        inventoryAlertsCount: lowStockItems.length,
      },
      machineWorkloads,
      primaryBottleneck,
      lowStockItems: lowStockItems.slice(0, 5),
      activeShopJobs,
      orderStatusDistribution: {
        Pending: allOrders.filter(o => o.status === "Pending").length,
        InProduction: allOrders.filter(o => o.status === "In Production").length,
        QualityReview: allOrders.filter(o => o.status === "Quality Review").length,
        Completed: allOrders.filter(o => o.status === "Completed").length,
        OnHold: allOrders.filter(o => o.status === "On Hold").length,
      }
    });

  } catch (error: any) {
    console.error("GET dashboard metrics error:", error);
    return NextResponse.json({ error: error?.message || "Failed to compute dashboard metrics" }, { status: 500 });
  }
}
