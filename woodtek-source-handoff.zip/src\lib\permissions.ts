// Shared role capability matrix.
// Safe to import from BOTH client components and server routes — no node-only imports here.
// The server is the enforcement point; the client uses this only to hide controls.

export type Action =
  | "orders:read"
  | "orders:write"
  | "orders:delete"
  | "operations:write"
  | "machines:read"
  | "machines:write"
  | "customers:read"
  | "customers:write"
  | "customers:delete"
  | "inventory:read"
  | "inventory:write"
  | "cmms:read"
  | "cmms:write"
  | "cmms:configure"
  | "reports:read"
  | "reports:write"
  | "users:read"
  | "users:manage"
  | "admin:seed";

export const ROLES = ["Manager", "Sales Coordinator", "Machine Operator", "QA & Dispatch", "Technician"] as const;
export type Role = (typeof ROLES)[number];

/** Everything a signed-in user may do regardless of role. */
const BASE_READ: Action[] = [
  "orders:read",
  "machines:read",
  "customers:read",
  "inventory:read",
  "cmms:read",
  "reports:read",
];

const MATRIX: Record<string, Action[]> = {
  Manager: [
    ...BASE_READ,
    "orders:write", "orders:delete",
    "operations:write",
    "machines:write",
    "customers:write", "customers:delete",
    "inventory:write",
    "cmms:write", "cmms:configure",
    "reports:write",
    "users:read", "users:manage",
    "admin:seed",
  ],
  "Sales Coordinator": [
    ...BASE_READ,
    "orders:write", "orders:delete",
    "customers:write",
    "reports:write",
  ],
  "Machine Operator": [
    ...BASE_READ,
    "operations:write",
    "inventory:write",
    "cmms:write",
  ],
  "QA & Dispatch": [
    ...BASE_READ,
    "orders:write",
    "operations:write",
    "inventory:write",
    "cmms:write",
    "reports:write",
  ],
  Technician: [
    ...BASE_READ,
    "machines:write",
    "operations:write",
    "cmms:write", "cmms:configure",
    "reports:write",
  ],
};

export function can(role: string | null | undefined, action: Action): boolean {
  if (!role) return false;
  return (MATRIX[role] ?? []).includes(action);
}

const LABELS: Record<Action, string> = {
  "orders:read": "view production orders",
  "orders:write": "create or edit production orders",
  "orders:delete": "delete production orders",
  "operations:write": "update shop floor operations",
  "machines:read": "view machines",
  "machines:write": "manage machine records",
  "customers:read": "view clients",
  "customers:write": "manage client accounts",
  "customers:delete": "delete client accounts",
  "inventory:read": "view stock",
  "inventory:write": "adjust material stock",
  "cmms:read": "view plant assets",
  "cmms:write": "record maintenance",
  "cmms:configure": "change CMMS configuration",
  "reports:read": "view reports",
  "reports:write": "generate reports",
  "users:read": "view staff accounts",
  "users:manage": "manage staff accounts",
  "admin:seed": "reset demo data",
};

export function deniedMessage(role: string | null | undefined, action: Action): string {
  return `Your role (${role ?? "guest"}) is not permitted to ${LABELS[action]}.`;
}
