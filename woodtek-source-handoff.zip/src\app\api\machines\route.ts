import { NextResponse } from "next/server";
import { db } from "@/db";
import { machines, users, orderOperations, orders } from "@/db/schema";
import { eq, asc, desc } from "drizzle-orm";
import { authorize } from "@/lib/auth";

export async function GET() {
  const { error: authError } = await authorize("machines:read");
  if (authError) return authError;

  try {
    const allMachines = await db
      .select({
        id: machines.id,
        name: machines.name,
        code: machines.code,
        category: machines.category,
        status: machines.status,
        hourlyCost: machines.hourlyCost,
        location: machines.location,
        maintenanceDue: machines.maintenanceDue,
        notes: machines.notes,
        createdAt: machines.createdAt,
        assignedOperatorId: machines.assignedOperatorId,
        operatorName: users.name,
        operatorRole: users.role,
        operatorAvatar: users.avatarColor,
      })
      .from(machines)
      .leftJoin(users, eq(machines.assignedOperatorId, users.id))
      .orderBy(asc(machines.code));

    // Fetch active operations queued on machines
    const allOps = await db
      .select({
        id: orderOperations.id,
        machineId: orderOperations.machineId,
        status: orderOperations.status,
        estimatedMinutes: orderOperations.estimatedMinutes,
        orderTitle: orders.title,
        orderNumber: orders.orderNumber,
      })
      .from(orderOperations)
      .leftJoin(orders, eq(orderOperations.orderId, orders.id));

    const enrichedMachines = allMachines.map(m => {
      const machineOps = allOps.filter(o => o.machineId === m.id && (o.status === "Ready" || o.status === "In Progress" || o.status === "Pending"));
      const activeJob = allOps.find(o => o.machineId === m.id && o.status === "In Progress") || null;
      const readyQueueCount = machineOps.filter(o => o.status === "Ready").length;
      const totalEstimatedMinutes = machineOps.reduce((sum, o) => sum + (o.estimatedMinutes || 0), 0);

      // Auto deduce status if in use and not marked maintenance
      let displayStatus = m.status;
      if (activeJob && displayStatus !== "Maintenance" && displayStatus !== "Offline") {
        displayStatus = "In-Use";
      }

      return {
        ...m,
        status: displayStatus,
        activeJob,
        queueCount: machineOps.length,
        readyQueueCount,
        totalQueueMinutes: totalEstimatedMinutes,
        queuedJobs: machineOps
      };
    });

    return NextResponse.json(enrichedMachines);
  } catch (error: any) {
    console.error("GET machines error:", error);
    return NextResponse.json({ error: error?.message || "Failed to fetch machines" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const { error: authError } = await authorize("machines:write");
  if (authError) return authError;

  try {
    const body = await request.json();
    const { name, code, category, status = "Active", hourlyCost = "65.00", location = "Shop Floor", assignedOperatorId, notes, maintenanceDue } = body;

    if (!name || !code || !category) {
      return NextResponse.json({ error: "Machine Name, Code, and Category are required." }, { status: 400 });
    }

    const [newMachine] = await db.insert(machines).values({
      name,
      code: code.toUpperCase(),
      category,
      status,
      hourlyCost: String(hourlyCost),
      location,
      assignedOperatorId: assignedOperatorId ? Number(assignedOperatorId) : null,
      notes: notes || null,
      maintenanceDue: maintenanceDue ? new Date(maintenanceDue) : null
    }).returning();

    return NextResponse.json(newMachine, { status: 201 });
  } catch (error: any) {
    console.error("POST machine error:", error);
    return NextResponse.json({ error: error?.message || "Failed to create machine" }, { status: 500 });
  }
}
